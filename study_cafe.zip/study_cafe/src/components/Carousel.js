import React from 'react'
import '../css/Carousel.css'

const Carousel = () => {
    return (
        <div id="carouselExampleCaptions" className="carousel slide mt-5" >
            <div className="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div className="carousel-inner">
                <div className="carousel-item active bgd">
                    <img src="./images/5.jpeg" className="d-block w-100 h-100vh bg-dark" alt="..." />
                    <div className="carousel-caption d-none d-md-block ">
                        <h5>Today a reader, tomorrow a leader Read to succeed</h5>
                        <p>If you read the more books so you can increse your Knowledge.</p>
                    </div>
                </div>
                <div className="carousel-item">
                    <img src="./images/2.jpg" className="d-block w-100 h-100vh bg-dark" alt="..." />
                    <div className="carousel-caption d-none d-md-block">
                        <h5>Education changes your bad today into good tomorrow</h5>
                        <p>Eduction is important to all ,for change own life</p>
                    </div>
                </div>
                <div className="carousel-item">
                    <img src="./images/1.jpg" className="d-block w-100 h-100vh" alt="..." />
                    <div className="carousel-caption d-none d-md-block">
                        <h5>Education is a key to the door of all the dreams</h5>
                        <p>Self study more better than group study</p>
                    </div>
                </div>
            </div>
            <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                <span className="visually-hidden">Previous</span>
            </button>
            <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                <span className="visually-hidden">Next</span>
            </button>
        </div>
    )
}

export default Carousel