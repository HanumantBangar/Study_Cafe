import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router';
import { Link } from 'react-router-dom';
import AdminLogin from './adminLogin';
import Footer from './Footer';

const UserDetails = () => {
  const { id } = useParams()
  console.log("Id is " + id);
  const [obj, setObj] = useState({})
  useEffect(() => {
    const getData = async () => {

      const data = await fetch("http://localhost:4500/search/" + id)
      const arr = await data.json()
      console.log(arr)

      setObj(arr[0])
    }

    getData()

  }, [])
  return (
    <div>
      <AdminLogin/>
      <div className='user'>
        <span className='back bg-dark'> <Link to="/home"><i class="fa-solid fa-arrow-left fa-2xl mb-4 text-light"></i></Link></span>
        <div class="card" style={{ maxWidth: '530px', border: '2px solid black' }}>
          <div class="row g-0">
            <div class="col-md-4">
              <img src="../images/profile.webp" class="img-fluid" alt="..." style={{ borderRadius: ' 0%', height: '188px', width: '175px' }} />
            </div>
            <div class="col-md-8">
              <div class="card-body" style={{ borderLeft: '2px solid black' }} >
                <h4 class="card-title mb-4 bg-new p-3 text-center" style={{ borderTopLeftRadius: '25px', borderTopRightRadius: '25px' }} >{obj.Name}</h4>
                <p class="card-text .text-danger-emphasis"><i class="fa fa-envelope me-3" aria-hidden="true"></i>{obj.Email}</p>
                <p class="card-text "><i class="fa fa-phone-square me-3" aria-hidden="true"></i>{obj.Contact}</p>
                <p class="card-text"><i class="fa fa-id-card me-3" aria-hidden="true"></i>{obj.UserSeat}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer/>
    </div>
  )
}
export default UserDetails;

//userDetails files