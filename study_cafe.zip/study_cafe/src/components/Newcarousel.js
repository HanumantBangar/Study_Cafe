import React from 'react'
import { Link } from 'react-router-dom'
import '../css/Newcarosel.css'
export const Newcarousel = () => {
    return (
        <div>
          
  <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
        aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
        aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
        aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="./images/studyimg2.jpg" class="d-block w-100" alt="..."/>
        <div class="carousel-caption">
        <h5>Today a reader, tomorrow a leader Read to succeed</h5>
                        <p>If you read the more books so you can increse your Knowledge.</p>
          <p><Link to="/about" class="btn  btn-warning mt-3">Learn more</Link></p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="./images/4.jpg" class="d-block w-100" alt="..."/>
        <div class="carousel-caption">
        <h5>Education changes your bad today into good tomorrow</h5>
                        <p>Eduction is important to all ,for change own life</p>
          <p><a href="#" class="btn  btn-warning mt-3">Learn more</a></p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="./images/5.jpeg" class="d-block w-100" alt="..."/>
        <div class="carousel-caption">
        <h5>Education is a key to the door of all the dreams </h5>
                        <p>Self study more better than group study</p>
          <p><a href="#" class="btn  btn-warning mt-3">Learn more</a></p>
        </div>
      </div>
    </div>

    
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
                </div>
            )
}
