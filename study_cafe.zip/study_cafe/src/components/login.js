import React from "react";
import '../css/login.css'
import ForgotPass from "./forgotPassword";
import { Link, useNavigate } from 'react-router-dom'
import Navbar from "./navbar";
import Footer from "./Footer";

function Login() {
    const [uname, setUname] = React.useState("");
    const [pass, setPass] = React.useState("");
    const [err, setErr] = React.useState(false);
    const [data, setData] = React.useState([]);
    const [id, setId] = React.useState("");
    const navigate = useNavigate();

    const handleUname = (event) => {
        setUname(event.target.value)
    }
    const handlePassword = (event) => {
        setPass(event.target.value)
    }


    const handleLogin = (event) => {
        event.preventDefault();
        const getData = async () => {

            const obj = await fetch("http://localhost:4500/login/" + uname + "/" + pass)
            // console.log(obj)
            const arr = await obj.json();
            console.log(arr);
            if (uname === "admin" && pass === "admin") {
                sessionStorage.setItem("admin","this is only for admin")
                    navigate("/adminPage");
            }
            else if (arr.length) {

                // alert("welcome");
                const data = JSON.stringify(arr[0]);
                sessionStorage.setItem("obj", data);
                navigate("/userProfile");
            }
            else {
                setErr("Invalid username or password.");
            }

            setData(arr[0]);
        }
        getData()
    }

    return (
        <div>
            <Navbar />
            <div className="conatiner loginmain">
                <div className="row">
                    <div className="lg-bg bg-light-grey">
                        <form>
                            <h1 className="text-secondary">Login Here..</h1>
                            <span>{err}</span>
                            <div className="form-group mb-3">
                                <label for="uname" className="mb-1">Username</label>
                                <input type="text" className="form-control" id="uname" placeholder="Enter username" onChange={handleUname} />
                            </div>
                            <div className="form-group mb-3">
                                <label for="password" className="mb-1">Password</label>
                                <input type="password" className="form-control" id="password" placeholder="Enter password" onChange={handlePassword} />
                            </div>
                            <div className="form-group mb-3 mt-4 text-center">
                                <input type="submit" className="form-control btn btn-primary" value="Login" onClick={handleLogin} />
                            </div>
                            <div className="fpass mb-3">
                                <Link to="/newRegistration">New Registration</Link>
                                <Link to="/forgotPassword" >Forgot Password</Link>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <Footer/>
        </div>
    );
};

export default Login;
