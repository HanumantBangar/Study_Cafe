import React from 'react'
import '../css/aboutUs.css'
import Footer from './Footer';
import Navbar from './navbar';

const Aboutus = () => {
    return (
        <div>
            <Navbar/>
            <div class="section mt-5">
                <div class="container">
                    <div class="title bg-new">
                        <h1>About us</h1>
                    </div>
                    <div class="content">
                        <div class="article">
                            <h3 >We know now days because of rush and traffics there are no any place where silence is present , for learners , readers. So our study café is that place where the people comes and read books , and do their self study silently without any disturbing. With help of our website user can easily reserve the seats. In study cafe we give silent enviroment which benifits for that student which do self study. We keep the books which releted to the goverment exam.We provided discussion room where the members discuss with each other.</h3>
                            <h2 className='abouttext'>" Education makes a person a responsible citizen "</h2>
                            <div class="button">
                                <a href="#">Read more</a>
                            </div>
                        </div>

                    </div>
                    <div class="image-section">
                        <img src="./images/cafeteria-armenia.jpg" alt="" />
                    </div>
                    <div class="social">
                        <a href=""><i class="fab fa-facebook-f"></i></a>
                        <a href=""><i class="fab fa-twitter"></i></a>
                        <a href=""><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <Footer/>
        </div>
    )
}

export default Aboutus;