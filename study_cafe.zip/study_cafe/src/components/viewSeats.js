import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import '../css/viewSeats.css'
import AdminLogin from './adminLogin';
import Footer from './Footer';

const ViewSeats = () => {
    const [data, setData] = React.useState([]);
    const [flag, setFlag] = React.useState("seat text-center bg-danger")

    const getData = async () => {
        const result = await fetch("http://localhost:4500/seats")
        const response = await result.json();
        setData(response)


    }
    console.log(data)
    useEffect(() => {
        getData();
    }, [])
    return (
        <div>
            <AdminLogin />
            <div className='container loginmain'>
                <span className='back bg-dark'> <Link to="/newRegistration" className='text-decoration-none text-light'><i class="fa-solid fa-arrow-left fa-2xl mb-4 text-light me-3"></i>Go to registration page</Link></span>
                <h1 className='text-center p-3 bg-new'>Available Seat Details</h1>
                <div className='ms-3'>
                    <div className='row flex-wrap mb-3'>
                        <div className='circle bg-success d-inline me-3'></div><div d-inline me-3>Availabel Seats</div>
                    </div>
                    <div className='row flex-wrap'>
                        <div className='circle bg-danger d-inline me-3'></div><div d-inline me-3>Reserved Seats</div>
                    </div>
                </div>
                <div className='row ustify-content-between text-light'>
                    {
                        data.map((element) => {
                            if (element.userseat != null) {
                                return <div className={flag}>{element.seatnumber}</div>
                            }
                            else {
                                return <div className='seat text-center bg-success text-light'>{element.seatnumber}</div>
                            }
                        })
                    }
                </div>
            </div>
            <Footer/>
        </div>
    );
};

export default ViewSeats;