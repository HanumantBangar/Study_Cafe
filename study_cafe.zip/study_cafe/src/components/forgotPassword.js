import React from "react";
import '../css/forgotPassword.css'

function ForgotPass(){
    return(
        <div className="container mt-5 fpp-bg"> 
            <div className="row">
                <div className="col">
                    <form>
                        <h1 className="text-secondary mb-5">Forgot Password Page..</h1>
                        <div className="form-group mb-3">
                            <label for="uname" className="mb-1">Username</label>
                            <input type="text" className="form-control" id="uname" placeholder="Enter username"/>
                        </div>
                        <div className="form-group mb-3">
                            <label for="password" className="mb-1">Password</label>
                            <input type="password" className="form-control" id="password" placeholder="Enter password"/>
                        </div>
                        <div className="form-group mb-3">
                            <label for="cpassword" className="mb-1">Confirm Password</label>
                            <input type="password" className="form-control" id="cpassword" placeholder="Enter confirm password"/>
                        </div>
                        <div className="form-group mb-3 mt-4">
                            <input type="submit" className="form-control btn btn-primary" value="Reset Password"/>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default ForgotPass;