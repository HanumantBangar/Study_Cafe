import { Link } from "react-router-dom";
import AdminLogin from "./adminLogin";
import Footer from "./Footer";
import Navbar from "./navbar";

function AddNewUser() {
    const handleSubmit = () => {
        alert("Data submited in database..");
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const contact = document.getElementById("contact").value;
        const uname = document.getElementById("uname").value;
        const password = document.getElementById("password").value;
        const seat = document.getElementById("seat").value;

        try {
            fetch("http://localhost:4500/", {
                method: "post",
                body: JSON.stringify({
                    uid: '0',
                    Name: name,
                    Email: email,
                    Contact: contact,
                    Username: uname,
                    Password: password,
                    UserSeat: seat
                }),
                headers: {
                    'Content-type': 'application/json; charset=UTF-8',
                },
            })
                .then((response) => response.json())
                .then((output) => {
                    console.log(output)
                })
        }
        catch (err) {
            console.log(err);
        }
    }

    return (
        <div>
            <AdminLogin />
            <div className="container login loginmain1">
                <div className="row">
                    <div className="col">
                        <form action="/login" onSubmit={handleSubmit}>
                            <h1 className="p-3 text-center bg-new">Registration Form..</h1>
                            <div className="form-group mb-3">
                                <label for="name">Name</label>
                                <input type="text" id="name" className="form-control" placeholder="*Enter name" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="email">Email</label>
                                <input type="text" id="email" className="form-control" placeholder="*Enter email" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="contact">Contact Number</label>
                                <input type="text" id="contact" className="form-control" placeholder="*Enter contact" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="uname">Username</label>
                                <input type="text" id="uname" className="form-control" placeholder="*Enter Username" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="password">Password</label>
                                <input type="password" id="password" className="form-control" placeholder="*Enter Password" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="seat">Seat Number <span>(Enter only number.)</span></label>
                                <input type="text" className="form-control" id="seat" placeholder="*Enter seat number" />
                                <div><Link to="/viewSeats">See Available Seats</Link></div>
                            </div>

                            <div className="form-group  mt-5">
                                <input type="reset" className="btn btn-primary me-5" value="Reset" />
                                <input type="submit" className="btn btn-primary" value="Register"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <Footer/>
        </div>
    )
}
export default AddNewUser;