import React from 'react'
import { Link } from 'react-router-dom'
import AdminLogin from './adminLogin'
import Footer from './Footer'
import ShowTable from './showTable'

const AdminPage=()=> {

  if(sessionStorage.getItem("admin")!=null)
  {
    return (
      <div>
          <AdminLogin/>
          <ShowTable/>
          <Footer/>
      </div>
    )
  }
  else{
    return <div className='text-center text-danger m-5'>You are invalid user. Please login first. <Link to="/login">Go to login</Link></div>
  }
    
}

export default AdminPage