import React from 'react'
import '../css/Gallery.css';
import Navbar from './navbar';
import Footer from './Footer'

const Gallery=()=> {
  return (
    <div>
        <Navbar/>
    <section class="gallery mt-5 ">
        <div class="container-lg ">
            <h2 class="text-center mb-5 bg-new p-3">GALLERY</h2>
              <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3">
                <div class="col">
                    <img src="../images/gallery1.jpg" class="gallery-item img-zoom" alt="gallery"/>
                </div>
                <div class="col">
                    <img src="../images/studyimg2.jpg" class="gallery-item img-zoom" alt="gallery"/>
                </div>
                <div class="col">
                    <img src="../images/gallery4.jpg" class="gallery-item img-zoom" alt="gallery"/>
                </div>
                <div class="col">
                    <img src="../images/wifi.jfif" class="gallery-item mt-3 img-zoom" alt="gallery"/>
                </div>
                <div class="col">
                    <img src="../images/newspaperimg1.jfif" class="gallery-item mt-3 img-zoom" alt="gallery"/>
                </div>
                <div class="col">
                    <img src="../images/environment.jpg" class="gallery-item mt-3 img-zoom" alt="gallery"/>
                </div>
              </div>
        </div>
    </section>
    <Footer/>
    </div>
  )
}

export default Gallery;