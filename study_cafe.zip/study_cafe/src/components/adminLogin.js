import { Link } from "react-router-dom";
const handleLogin=()=>{
    sessionStorage.clear();
}

const AdminLogin = () => {
    return (
            <nav className="navbar navbar-expand-lg bg-dark text-light fixed-top" >
                <div className="container-fluid fs-5 ms-3">
                    <Link className="navbar-brand text-light fs-2" to="/"><span className="text-warning fs-1">S</span>tudy<span className="text-danger fs-1">C</span>afe</Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon bg-light text-light"></span>
                    </button>
                    <div className="collapse navbar-collapse col-6 justify-content-end" id="navbarNavAltMarkup">
                        <div className="navbar-nav">
                            <Link className="nav-link text-light me-3" aria-current="page" to="/">Home</Link>
                            <Link className="nav-link text-light me-3" to="/addNewUser">Add User</Link>
                            <Link className="nav-link text-light me-3" to="/showTable">View Users</Link>
                            <Link className="nav-link text-light me-3" to="/viewSeats">Available Seats</Link>
                            <Link className="nav-link text-light me-3 btn btn-danger" to="/login" onClick={handleLogin}>Logout</Link>
                        </div>
                    </div>
                </div>
            </nav>
    );
}

export default AdminLogin;