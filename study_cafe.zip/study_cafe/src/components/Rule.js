import React from 'react'
import '../css/rule.css'
const Rules = () => {
  return (
    <div className='container mt-5 '>
      <div class="rules" >
        <h1 class="mb-5 text-center bg-new p-3">RULES AND TIMING</h1>
        <ul type="none">
          <li><i class="fa fa-chevron-circle-right" aria-hidden="true"></i> Don't write anything on your table.</li>
          <li><i class="fa fa-chevron-circle-right" aria-hidden="true"></i> Drinking and smoking not allowed.</li>
          <li><i class="fa fa-chevron-circle-right" aria-hidden="true"></i> Do not throw any waste in reading room.</li>
          <li><i class="fa fa-chevron-circle-right" aria-hidden="true"></i> Keep your phone at silent.</li>
          <li><i class="fa fa-chevron-circle-right" aria-hidden="true"></i> Don't leave your personal belongings on your seat.</li>
          <li><i class="fa fa-chevron-circle-right" aria-hidden="true"></i> Your Seat can be allotted to other student if found vacant for more than 1 hour.</li>
        </ul>
        <div className='border border-black p-3 text-center'><h3>Library will remain open <span className='text-warning'>24*7</span> except the last sunday of every month.</h3>
          <div className='text-center'><img src="./images/open.jpg"  style={{ height: "80px", width: "70px" }} /></div></div>
      </div>
    </div>
  )
}

export default Rules