import React, { useEffect, useState } from "react";
import $, { param } from 'jquery'
import { Link } from "react-router-dom";
import UserDisplay from "./UserDisplay";
import AdminLogin from "./adminLogin";
import Footer from "./Footer";
const ShowTable = () => {
    const [data, setData] = React.useState([])
    const [flag, setFlag] = React.useState(false)
    const [id, setId] = useState(0)
    const [del, setDel] = React.useState();
    const getData = () => {
        fetch("http://localhost:4500/")
            .then((response) => {
                console.log(response.status);
                console.log(response.ok);
                return response.json()
            })

            .then((obj) => {
                console.log(obj)
                setData(obj);
                // console.log(obj)
                // let arr=obj;
                // let tr=`<tr><th>Sid</th><th>Name</th><th>Email</th><th>Contact</th></tr>`;
                // obj.map(ele => {
                //     const tr = `<tr><td>${ele.Name}</td><td>${ele.Email}</td><td>${ele.Contact}</td><td><i class="fa-sharp fa-solid fa-eye"></i></td></tr>`;
                //     $('table').append(tr);
                //     // document.querySelector("table").append(tr);
                // });
            })
    }
    const handleBtn = (event) => {
        setFlag(true)
        console.log(event.target.name)
        setId(event.target.name)


    }
    useEffect(() => {
        getData();
    }, [])

    // ==================================================================
    // delete api

    const handleDelete = (id) => {
        console.log("delete id " + id)

        const deleteApi = async () => {
            const result = await fetch("http://localhost:4500/delete/" + id, {
                method: "delete"
            })
            const response = await result.json();
            console.log(response);
        }

            ;
        if (window.confirm("Are you sure !")) {
            deleteApi();
            getData();
        }


    }

    return (
        <div>
            <AdminLogin />

            <div className="loginmain px-5">
                {/* <span className='back bg-dark'> <Link to="/adminPage"><i class="fa-solid fa-arrow-left fa-2xl mb-4 text-light"></i></Link></span> */}
                <table className="table table-striped">
                    <thead>
                        <tr className="bg-new text-center" >
                            <th >Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Seat No</th>
                            <th></th>
                            <th>Actions</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            data.map(ele =>


                                <tr key={ele.Uid} className="text-center" ><td>{ele.Name}</td><td>{ele.Email}</td><td>{ele.Contact}</td><td>{ele.UserSeat}</td><td><Link to={`/userDetail/${ele.Uid}`}><i class="fa-sharp fa-solid fa-eye"></i></Link></td><td><Link to={`/edit/${ele.Uid}`}><i class="fa-solid fa-pencil"></i></Link></td><td onClick={() => handleDelete(ele.Uid)}><Link><i class="fa-solid fa-trash"></i></Link></td></tr>

                                //  <tr key={ele.Uid} className="text-center"><td>{ele.Name}</td><td>{ele.Email}</td><td>{ele.Contact}</td><td>{ele.UserSeat}</td><td><Link to={`/userDetail/${ele.Uid}`}><i class="fa-sharp fa-solid fa-eye"></i></Link></td><td><input type="button" value="click me" name={ele.Uid}  onClick={handleBtn}/></td></tr>
                            )
                        }
                    </tbody>
                </table>
                {flag &&
                    <div><UserDisplay userId={id} /></div>}
            </div>
            <Footer />
        </div>
    );
};

export default ShowTable;