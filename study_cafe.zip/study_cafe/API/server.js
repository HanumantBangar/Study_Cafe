const express=require('express');
const mysql=require('mysql')
const app=express();
const cors=require('cors');
app.use(cors());
app.use(express.json());

const con=mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "hanumant"
});

con.connect((error)=>{
    if(error)
        console.log("Database Not Connected..");
    else
        console.log("Database Connected..")
});



app.get("/",(req,resp)=>{
    con.query('select * from userdetails',(error,result)=>{
        if(error)
            console.log("Error is "+error);
        else
            resp.send(result);
    });
});

app.get("/seats",(req,resp)=>{
  con.query('select u.userseat,s.seatnumber from userdetails u right join seats s on s.sid=u.userseat',(error,result)=>{
      if(error)
          console.log("Error is "+error);
      else
          resp.send(result);
  });
});

app.get("/search/:id",(req,res)=>{
    let id=req.params.id;
    con.query("select * from userdetails where Uid=?",[id],function(err,result){
      if(err){
        res.send("error")
      }else{
        res.send(result)
      }
    })
  })

app.get("/login/:username/:password",(req,res)=>{
    let username=req.params.username;
    let password=req.params.password;
    con.query("select * from userdetails where Username=? and Password=?",[username,password],function(err,result){
      if(err){
        res.send("error")
      }else{
        res.send(result)
        return result;
      }
    })
  })

app.post("/",(req,resp)=>{
    const data=req.body;
    con.query('insert into userdetails set ?',data,(error,result,fields)=>{
        if(error)
            console.log("error is "+error);
        else
        {
            resp.send("successfully..");
            return result;
        }
    });
});

app.patch("/edit/:id",(req,resp)=>{
  const data=[req.body.Name,req.body.Email,req.body.Contact, req.params.id]
  con.query('update userdetails set Name=?, Email=?, Contact=? where Uid=?',data,(error,result,fields)=>{
      if(error)
          console.log("error is "+error);
      else
      {
          resp.send("successfully..");
          return result;
      }
  });
});

app.delete("/delete/:id",(req,resp)=>{
  const id=req.params.id;
  con.query('delete from userdetails where Uid=?',[id],(error,result,fields)=>{
    if(error)
          console.log("error is "+error);
      else
      {
          resp.send("successfully..");
          return result;
      }
  })
});

app.listen(4500);

// 'select u.name,u.email,u.contact,s.seatnumber,m.expirydate from user u inner join usejoin uj on uj.uid=u.uid inner join seats s on s.sid=uj.sid inner join membership m on m.mid=uj.mid'