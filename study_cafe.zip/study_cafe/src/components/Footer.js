import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
    return (
        <div className='container-fluid bg-dark text-light  mt-5'>
            <div className='row py-4'>
                <h1 className='ms-4'><span className='text-warning'>S</span>tudy <span className='text-danger'>C</span>afe</h1>
            </div>
            <div className='row mb-5 ms-3'>
                <div className='col-sm-12 col-md-3'>
                    <h3 className='mb-3'>About Us</h3>
                    <p className='lh-md'>StudyCafe is best platform for student or  professionals to study. We provide best envirment for study from last 5 years and the user expericence is also very good.</p>
                    <Link to="/about">Read more</Link>
                </div>
                <div className='col-sm-12 col-md-3'>
                    <h3 className='mb-3'>Services</h3>
                    <ul className='p-0 m-0 list-style-none'>
                        <li className='mb-3'><span className='text-primary me-2'><i class="fa-solid fa-angle-right"></i></span>Separate compartments</li>
                        <li className='mb-3'><span className='text-primary me-2'><i class="fa-solid fa-angle-right"></i></span>Free Wifi</li>
                        <li className='mb-3'><span className='text-primary me-2'><i class="fa-solid fa-angle-right"></i></span>Newspapers</li>
                        <li className='mb-3'><span className='text-primary me-2'><i class="fa-solid fa-angle-right"></i></span>Discussion Room</li>
                        <li className='mb-3'><span className='text-primary me-2'><i class="fa-solid fa-angle-right"></i></span>Lockers</li>
                    </ul>
                </div>
                <div className='col-sm-12 col-md-3'>
                    <h3 className='mb-3'>Contact Us</h3>
                    <ul className='p-0 m-0 list-style-none'>
                        <li className='mb-3'><i class="fa-solid fa-location-dot text-light"></i><span className='ms-3'>SN.45, Study-Cafe Warje,</span><span className='d-block ms-4'> Malwadi Pune-411058</span> </li>
                        <li className='mb-3'><i class="fa-solid fa-envelope"></i><span className='ms-3 '>studycafe03@gamil.com</span></li>
                        <li><i class="fa-solid fa-phone"></i><span className='ms-3'>9579284114</span></li>
                    </ul>
                </div>
                <div className='col-sm-12 col-md-3'>
                    <h3 className='mb-3'>Follow Us</h3>
                    <ul className='p-0 m-0 list-style-none d-flex'>
                        <li><Link><i class="fa-brands fa-facebook fs-2 text-white me-3"></i></Link></li>
                        <li><Link><i class="fa-brands fa-twitter fs-2 text-light me-3"></i></Link></li>
                        <li><Link><i class="fa-brands fa-instagram fs-2 text-light me-3"></i></Link></li>
                        <li><Link><i class="fa-brands fa-linkedin fs-2 text-light me-3"></i></Link></li>
                    </ul>
                </div>
            </div>
            <div>
                <div className='col'>
                    <hr></hr>
                    <h6 className='text-center py-4'>Copyright 2022 <span className='text-primary'>StudyCafe.com</span> | All Rights Reserved.</h6>
                </div>
            </div>
        </div>
    )
}

export default Footer