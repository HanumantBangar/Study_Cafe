import React from 'react'
import Carousel from './Carousel'
import Membership from './Membership'
import Rules from './Rule'
import Services from './Services'
import Navbar from './navbar'
import Footer from './Footer'
import { Newcarousel } from './Newcarousel'

const Home=()=> {
  return (
    <div>
        <Navbar/>
       { <Newcarousel/>}
        <Services/>
        <Rules/>
        <Membership/>
        <Footer/>
    </div>
  )
}

export default Home