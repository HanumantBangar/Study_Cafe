import React from 'react'
import { Link } from 'react-router-dom'

const Membership=()=> {
  return (
    <div className='container mt-5 mb-3 p-4 bg-new'>
        <h1>Membership Plans</h1>
        <div className='row justify-content-between'>
            <div className='col-4f bg-secondary text-center p-4 m-1'>
                <h3 className='text-light text-center p-2'><i class="fa-solid fa-indian-rupee-sign me-2"></i>49 / Day</h3>
                <Link className='btn btn-warning' to="/login">Buy Now</Link>
            </div>
            <div className='col-4f bg-secondary text-center p-4 m-1'>
                <h3 className='text-light text-center p-2'><i class="fa-solid fa-indian-rupee-sign me-2"></i>349 / Week</h3>
                <Link className='btn btn-warning' to="/login">Buy Now</Link>
            </div>
            <div className='col-4f bg-secondary text-center p-4 m-1'>
                <h3 className='text-light text-center p-2'><i class="fa-solid fa-indian-rupee-sign me-2"></i>999 / Month</h3>
                <Link className='btn btn-warning' to="/login">Buy Now</Link>
            </div>
        </div>
    </div>
  )
}

export default Membership