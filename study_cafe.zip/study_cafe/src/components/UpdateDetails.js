import React from 'react'
import { Link, useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';
import { useEffect } from 'react';
import { useState } from 'react';
import AdminLogin from './adminLogin';
import Footer from './Footer';

const UpdateDetails = () => {
    const navigate=useNavigate
    const { id } = useParams()
    // console.log("Id is " + id);
    const [obj, setObj] = useState({
        Name: "",
        Email: "",
        Contact: ""
    })
    useEffect(() => {
        const getData = async () => {

            const data = await fetch("http://localhost:4500/search/" + id)
            const arr = await data.json()
            console.log(arr)

            setObj(arr[0])
        }

        getData()

    }, [])

    const setData = (e) => {
        console.log(e.target.value);
        const { name, value } = e.target;
        setObj((preval) => {
            return {
                ...preval,
                [name]: value
            }
        })
    }

    const handleUpdate = async (e) => {
        e.preventDefault();
        const updateData = async() => {
            const { Name, Email, Contact } = obj;
            const result = await fetch("http://localhost:4500/edit/" + id, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    Name, Email, Contact
                })

            });
            const data = await result.json();
            console.log(data);
        }
        updateData();
        alert("Data save successfully..");
        navigate("/login");
    }


    return (
        <div>
            <AdminLogin />
            <div className="container login loginmain1">
                <div className="row">
                    <div className="col">
                        <form action="/login" onSubmit={handleUpdate}>
                            <h1 className="bg-new p-3 text-center">Update User Details..</h1>
                            <div className="form-group mb-3">
                                <label for="name">Name</label>
                                <input type="text" id="name" name="Name" className="form-control" placeholder="*Enter name" value={obj.Name} onChange={setData} />
                            </div>

                            <div className="form-group mb-3">
                                <label for="email">Email</label>
                                <input type="text" id="email" name="Email" className="form-control" placeholder="*Enter email" value={obj.Email} onChange={setData} />
                            </div>

                            <div className="form-group mb-3">
                                <label for="contact">Contact Number</label>
                                <input type="text" id="contact" name="Contact" className="form-control" placeholder="*Enter contact" value={obj.Contact} onChange={setData} />
                            </div>

                            <div className="form-group  mt-5">
                                <input type="submit" className="btn btn-primary" value="Update" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    )
}

export default UpdateDetails;