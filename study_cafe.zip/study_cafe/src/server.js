const express=require('express');
const mysql=require('mysql')
const app=express();
const cors=require('cors');
app.use(cors());
app.use(express.json());

const con=mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "hanumant"
});

con.connect((error)=>{
    if(error)
        console.log("Database Not Connected..");
    else
        console.log("Database Connected..")
});



app.get("/",(req,resp)=>{
    con.query('select * from student',(error,result)=>{
        if(error)
            console.log("Error is "+error);
        else
            resp.send(result);
    });
});

app.post("/",(req,resp)=>{
    const data=req.body;
    con.query('insert into student set ?',data,(error,result,fields)=>{
        if(error)
            console.log("error is "+error);
        else
            resp.send(result);
    });
})