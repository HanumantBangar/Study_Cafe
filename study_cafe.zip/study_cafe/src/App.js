import logo from './logo.svg';
import './App.css';
import Login from './components/login';
import ForgotPass from './components/forgotPassword';
import Registration from './components/registration';
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Navbar from './components/navbar';
import StudLogin from './components/studentLogin';
import AdminLogin from './components/adminLogin';
import ShowTable from './components/showTable';
import ViewSeats from './components/viewSeats';
import UserDetails from './components/userDetails';
import Carousel from './components/Carousel';
import Services from './components/Services';
import Footer from './components/Footer';
import Membership from './components/Membership';
import Home from './components/Home';
import Aboutus from './components/Aboutus';
import Gallery from './components/Gallery';
import UserProfile from './components/UserProfile';
import UpdateDetails from './components/UpdateDetails';
import AdminPage from './components/AdminPage';
import AddNewUser from './components/AddNewUser';

function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/userDetail/:id" element={<UserDetails />} />
          <Route path="/navigation" element={<Navbar />} />
          <Route path="/edit/:id" element={<UpdateDetails />} />
          <Route path="/" element={<Home />} />
          <Route path="/admin" element={<AdminLogin />} />
          <Route path="/showTable" element={<ShowTable />} />
          <Route path="/about" element={<Aboutus />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/adminPage" element={<AdminPage />} />
          <Route path="/forgotPassword" element={<ForgotPass />} />
          <Route path="/login" element={<Login />} />
          <Route path="/newRegistration" element={<Registration />} />
          <Route path="/addNewUser" element={<AddNewUser />} />
          <Route path="/viewSeats" element={<ViewSeats />} />
          <Route path="/userProfile" element={<UserProfile />} />
          <Route path="/footer" element={<Footer />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
