import React from 'react'
import { Link } from 'react-router-dom';
import AdminLogin from './adminLogin';
import Footer from './Footer';
import Navbar from './navbar';
import UserLoginNav from './UserLoginNav';


const UserProfile = () => {
  const data = sessionStorage.getItem("obj");
  const obj = JSON.parse(data);
  if(data!=null){
    return (
      <div>
        <UserLoginNav />
        <div className='user'>
          <span className='back bg-dark'> <Link to="/home"><i class="fa-solid fa-arrow-left fa-2xl mb-4 text-light"></i></Link></span>
          <div class="card" style={{ maxWidth: '530px', border: '2px solid black' }}>
            <div class="row g-0">
              <div class="col-md-4">
                <img src="./images/profile.webp" class="img-fluid" alt="..." style={{ borderRadius: ' 0%', height: '188px', width: '175px' }} />
              </div>
              <div class="col-md-8">
                <div class="card-body" style={{ borderLeft: '2px solid black' }} >
                  <h4 class="card-title mb-4 bg-new p-3 text-center" style={{ borderTopLeftRadius: '25px', borderTopRightRadius: '25px' }} >{obj.Name}</h4>
                  <p class="card-text .text-danger-emphasis"><i class="fa fa-envelope me-3" aria-hidden="true"></i>{obj.Email}</p>
                  <p class="card-text "><i class="fa fa-phone-square me-3" aria-hidden="true"></i>{obj.Contact}</p>
                  <p class="card-text"><i class="fa fa-id-card me-3" aria-hidden="true"></i>{obj.UserSeat}</p>
                </div>
              </div>
            </div>
  
          </div>
        </div>
        <Footer />
      </div>
    )
  }
  else{
    return <div className='text-center text-danger m-5'>You are invalid user. Please login first. <Link to="/login">Go to login</Link></div>
  }
  
}
export default UserProfile