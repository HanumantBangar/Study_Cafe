import React from "react";


const StudLogin = () => {
    const [data,setData]=React.useState("Hii hanumant");
    const count=()=>{
        setData("welcome Hanumant")
    }
    return (
        <div className="container">
            <div className="row">
                <div className="col-4 bg-dark text-light text-center">
                    <h3>Show Profile</h3>
                </div>
                <div className="col-8">
                    <div class="card text-bg-primary mb-3">
                        <div class="card-header"><h1>Student Profile</h1></div>
                        <div class="card-body">
                            <h5 class="card-title">{ data}</h5>
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                        <input type="button" onClick={count} value="click me"/>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default StudLogin;

