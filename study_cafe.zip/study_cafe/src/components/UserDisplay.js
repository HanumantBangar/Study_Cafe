import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router'

const UserDisplay = (props) => {
   const [obj,setObj]=useState({})

    useEffect(()=>{
        const getData=async()=>{
             
             const data=  await fetch("http://localhost:4500/search/"+props.userId)
         const arr = await data.json()
         console.log(arr)
     
         setObj(arr[0])
         }
     
         getData()
        
        },[props.userId])

  return (
    <div>Name:{obj.Name}<br/>
    Email:{obj.Email} <br/>
    Contact:{obj.Contact}<br/>
    Username:{obj.Username}<br/>

    </div>
  )
}

export default UserDisplay

//userDisplay file