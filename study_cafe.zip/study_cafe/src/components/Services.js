import React from 'react'

const Services=()=> {
  return (
    <div className='container bg-light mt-3'>
        <div className='row p-3 bg-new'>
        <h1 className='text-center'>Our Services</h1>
        </div>
        
        <div className='row'>
            <div className=' col-12 col-md-6'>
                <img src='./images/5.jpeg' className='w-100'></img>
            </div>
            <div className='col-12 col-md-6 '>
                <h2 className='ms-5 mb-5 mt-3'>Seperate Discussion Room</h2>
                <p className='ms-5  lh-lg'>The Library has 2 discussion rooms with an average seating of 8-10 students. Primarily, the discussion rooms are used for group study, group discussion and tutorials. Sometimes, the rooms are used for interviews and meetings. Each room is equipped with an LCD TV, a desktop computer, an HDMI cable and a whiteboard. Rooms are not soundproof.</p>
                <p className='ms-5  lh-lg'>This SOP provide guidelines which ensure discussion rooms are properly allocated for use by students, faculty and staff members</p>
            </div>
        </div>

        <div className='row'>
            <div className='col-12 col-md-6'>
                <h2 className='text-dark mt-5 mb-5'>Marathi, Hindi and English Language Newspapers available</h2>
                <p className='lh-lg'>Newspapers carry the news of the world. Newspapers provide information and general knowledge. Newspapers provide news about a country's economic situation, sports, games, entertainment, trade and commerce. Reading newspaper makes a good habit and it is already part of the modern life.</p>
                <p className='lh-lg'>Newspaper is quite a powerful tool that circulates information to people.</p>
            </div>
            <div className='col-12 col-md-6'>
                <img src='./images/6.jpg' className='w-100'></img>
            </div>
        </div>
        
        <div className='row'>
            <div className=' col-12 col-md-6'>
                <img src='./images/locker.jpg' className='w-100'></img>
            </div>
            <div className='col-12 col-md-6 mt-3'>
                <h2 className='ms-5 mb-5'>Locker Facility Available </h2>
                <p className='ms-5  lh-lg'>Library lockers provide a convenient and safe way for library users and even staff members to borrow and return library material 24h per day – no time limit applies with this new method..</p>
                <p className='ms-5  lh-lg'>A designated space to secure personal belongings, change, and prepare for the workday ahead helps maintain and often even improve productivity.</p>
            </div>
        </div>

        <div className='row'>
            <div className='col-12 col-md-6'>
                <h2 className='text-dark mt-5 mb-5'>Free <span className='text-primary fs-1'>Wifi</span> Facility available</h2>
                <p className='lh-lg'>WiFi technology is a wireless technology that allows devices access to the internet without the need for cables. Depending on the router and the connection, it has a range of around 100 meters. The connection is possible through infrared and radiofrequency waves.</p>
                <p className='lh-lg'>Enjoy high speed internet speed upto 100 mbps</p>
            </div>
            <div className='col-12 col-md-6'>
                <img src='./images/Wifi.jpg' className='w-100'></img>
            </div>
        </div>

    </div>
  )
}

export default Services